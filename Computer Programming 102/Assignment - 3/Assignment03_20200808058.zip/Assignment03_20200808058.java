//Tahir Emre Semiz
//20.05.2022

import java.io.FileWriter;
import java.io.IOException;
import java.security.InvalidParameterException;
import java.util.*;

public class Assignment03_20200808058 {
    public static void main(String[] args){
    }
}
class Transaction{
    private int type;
    private String to;
    private String from;
    private double amount;
    Transaction(int type,String to,String from,double amount){
        if(type == 1 || type == 2 || type == 3)
            this.type = type;
        else
            throw new InvalidParameterException();
        this.to = to;
        this.from = from;
        this.amount = amount;
    }
    Transaction(int type,String acctNo,double amount){
        if(type == 1) {
            this.type = type;
            this.to = acctNo;
            this.amount = amount;
        }
        else if(type == 3){
            this.type = type;
            this.from = acctNo;
        }
        else
            throw new InvalidParameterException();
    }
    public int getType() {
        return type;
    }
    public String getTo() {
        return to;
    }
    public String getFrom() {
        return from;
    }
    public double getAmount() {
        return amount;
    }
}
class Bank{
    private String Name;
    private String Address;
    private ArrayList<Customer> Customers = new ArrayList<>();
    private ArrayList<Company> Companies = new ArrayList<>();
    private ArrayList<Account> Accounts = new ArrayList<>();
    public Bank(String name,String address){
        this.Name = name;
        this.Address = address;
    }
    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }
    public String getAddress() {
        return Address;
    }
    public void setAddress(String address) {
        Address = address;
    }
    public void addCustomer(int id,String name,String surname){
        Customer c = new Customer(id,name,surname);
        this.Customers.add(c);
    }
    public void addCompany(int id,String name){
        Company c = new Company(id,name);
        this.Companies.add(c);
    }
    public void addAccount(Account account){
        this.Accounts.add(account);
    }
    public Customer getCustomer(int id){
        Customer c = null;
        for(int i = 0; i < Customers.size();i++){
            if(Customers.get(i).getId() == id)
                c = Customers.get(i);
        }
        if (c == null)
            throw new CustomerNotFoundException(id);
        else return c;
    }
    public Customer getCustomer(String name,String surname){
        Customer c = null;
        for(int i = 0; i < Customers.size();i++){
            if(Customers.get(i).getName().equals(name) &&
                    Customers.get(i).getSurname().equals(surname)){
                c = Customers.get(i);
            }
        }
        if (c == null)
            throw new CustomerNotFoundException(name,surname);
        else return c;
    }
    public Company getCompany(int id){
        Company c = null;
        for(int i = 0; i < Companies.size();i++){
            if(Companies.get(i).getId() == id)
                c = Companies.get(i);
        }
        if (c == null)
            throw new CompanyNotFoundException(id);
        else return c;
    }
    public Company getCompany(String name){
        Company c = null;
        for(int i = 0; i < Companies.size();i++){
            if(Companies.get(i).getName().equals(name))
                c = Companies.get(i);
        }
        if (c == null)
            throw new CompanyNotFoundException(name);
        else return c;
    }
    public Account getAccount(String accountNum){
        Account c = null;
        for(int i = 0; i < Accounts.size();i++){
            if(Accounts.get(i).getAcctNumber().equals(accountNum))
                c = Accounts.get(i);
        }
        if (c == null)
            throw new AccountNotFoundException(accountNum);
        else return c;
    }
    public void transferFunds(String accountFrom,String accountTo,double amount){
        getAccount(accountFrom).withdrawal(amount);
        getAccount(accountTo).deposit(amount);
    }
    public void closeAccount(String accountNum){
        Account c = null;
        for(int i = 0; i < Accounts.size();i++){
            if(Accounts.get(i).getAcctNumber().equals(accountNum))
                c = Accounts.get(i);
            if (Accounts.get(i).getBalance() > 0)
                throw new BalanceRemainingException(Accounts.get(i).getBalance());
            else
                Accounts.remove(i);
        }
        if (c == null)
            throw new AccountNotFoundException(accountNum);
    }
    public void processTransactions(List<Transaction> transactions,String outFile) throws IOException {
        Collections.sort(transactions,new transactionComparator());
        int c = 0;
        try{
            for(int i = 0;i < transactions.size();i++ ) {
                if (transactions.get(i).getType() == 1) {
                    getAccount(transactions.get(i).getTo()).deposit(transactions.get(i).getAmount());
                } else if (transactions.get(i).getType() == 2) {
                    getAccount(transactions.get(i).getFrom()).withdrawal(transactions.get(i).getAmount());
                    getAccount(transactions.get(i).getTo()).deposit(transactions.get(i).getAmount());
                } else
                    getAccount(transactions.get(i).getFrom()).withdrawal(transactions.get(i).getAmount());
                c++;
            }
        }catch(Exception e){
            FileWriter myWriter = new FileWriter(outFile);
            myWriter.write("ERROR: " + e.getClass().getName() + ": " +
                    transactions.get(c).getType() + "\t" +
                    transactions.get(c).getTo() + "\t" +
                    transactions.get(c).getFrom() + "\t" +
                    transactions.get(c).getAmount());
            myWriter.close();
        }
    }
    @Override
    public String toString(){
        String c = getName() + "\t" + getAddress() + "\n";
        for(int j = 0; j < Companies.size(); j++){
            c += "\t" + Companies.get(j).getName() + "\n";
            for (int k = 0; k < Companies.get(j).getBusinessAccounts().size(); k++) {
                c += "      " + Companies.get(j).getBusinessAccounts().get(k).getAcctNumber() +
                        "  " + Companies.get(j).getBusinessAccounts().get(k).getRate() +
                        "  " + Companies.get(j).getBusinessAccounts().get(k).getBalance() + "\n";
            }
        }
        for(int m = 0; m < Customers.size(); m++){
            c += "\t" + Customers.get(m).getName() + " " + Customers.get(m).getSurname() + "\n";
            for (int k = 0; k < Customers.get(m).getPersonalAccounts().size(); k++) {
                c += "      " + Customers.get(m).getPersonalAccounts().get(k).getAcctNumber() +
                        "  " + Customers.get(m).getPersonalAccounts().get(k).getBalance() + "\n";
            }
        }
        return c;
    }
}
class Account{
    private String acctNumber;
    private double Balance;
    Account(String acctNumber){
        this.acctNumber = acctNumber;
        this.Balance = 0;
    }
    Account(String acctNumber, double Balance){
        this.acctNumber = acctNumber;
        if(Balance < 0)
            this.Balance = 0;
        else
            this.Balance = Balance;
    }
    public String getAcctNumber(){
        return acctNumber;
    }

    public double getBalance() {
        return Balance;
    }
    public void deposit(double amount) {
        try {
            if (amount < 0)
                throw new InvalidAmountException(amount);
            else
                this.Balance += amount;
        }
        catch (InvalidAmountException e){
            System.out.println(e);
        }
    }
    public void withdrawal(double amount){
        try{
            if(amount < 0 || amount > getBalance())
                throw new InvalidAmountException(amount);
            else
                this.Balance -= amount;
        }
        catch (InvalidAmountException e){
            System.out.println(e);
        }
    }
    @Override
    public String toString(){
        return "Account " + this.acctNumber + " has " + this.Balance;
    }
}
class PersonalAccount extends Account{
    private String Name;
    private String Surname;
    private String PIN;
    public PersonalAccount(String acctNumber, String Name, String Surname){
        super(acctNumber);
        this.Name = Name;
        this.Surname = Surname;
        Random random = new Random();
        this.PIN = String.format("%04d", random.nextInt(10000));
    }
    public PersonalAccount(String acctNumber, String Name,
                           String Surname, double Balance){
        super(acctNumber,Balance);
        this.Name = Name;
        this.Surname = Surname;
        Random random = new Random();
        this.PIN = String.format("%04d", random.nextInt(10000));
    }
    public String getName() {
        return Name;
    }
    public String getSurname() {
        return Surname;
    }
    public String getPIN() {
        return PIN;
    }
    public void setName(String name) {
        Name = name;
    }
    public void setSurname(String surname) {
        Surname = surname;
    }
    public void setPIN(String PIN) {
        this.PIN = PIN;
    }
    @Override
    public String toString(){
        return "Account " + getAcctNumber() + " belonging to "
                + getName() + " " + getSurname().toUpperCase() +
                " has " + getBalance();
    }
}
class BusinessAccount extends Account{
    private double interestRate;
    public BusinessAccount(String acctNumber, double interestRate){
        super(acctNumber);
        if (interestRate < 0)
            this.interestRate = 0;
        else
            this.interestRate = interestRate;
    }
    public BusinessAccount(String acctNumber,double Balance,
                           double interestRate){
        super(acctNumber,Balance);
        if (interestRate < 0)
            this.interestRate = 0;
        else
            this.interestRate = interestRate;
    }
    public double getRate() {
        return interestRate;
    }

    public void setRate(double rate) {
        if (rate > 0)
            this.interestRate = rate;
    }
    public double calculateInterest(){
        double a = getBalance();
        return (a * getRate());
    }
}
class Customer{
    private int id;
    private String Name;
    private String Surname;
    private ArrayList<PersonalAccount> PersonalAccounts = new ArrayList<>();
    public ArrayList<PersonalAccount> getPersonalAccounts() {
        return PersonalAccounts;
    }
    public Customer(int id, String Name, String Surname){
        if (id < 0)
            throw new InvalidIdException(id);
        else
            this.id = id;
        this.Name = Name;
        this.Surname = Surname;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return Name;
    }
    public String getSurname() {
        return Surname;
    }
    public void setName(String name) {
        Name = name;
    }
    public void setSurname(String surname) {
        Surname = surname;
    }
    public void openAccount(String acctNum){
        PersonalAccount s = new PersonalAccount(acctNum,Name,Surname);
        this.PersonalAccounts.add(s);
    }
    public PersonalAccount getAccount(String acctNum){
        PersonalAccount c = null;
        for(int i = 0; i < PersonalAccounts.size();i++){
            if(PersonalAccounts.get(i).getAcctNumber().equals(acctNum)) {
                c = PersonalAccounts.get(i);
            }
        }
        if(c == null)
            throw new AccountNotFoundException(acctNum);
        else return c;
    }
    public void closeAccount(String acctNum){
        PersonalAccount c = null;
        for(int i = 0; i < PersonalAccounts.size();i++){
            if(PersonalAccounts.get(i).getAcctNumber().equals(acctNum))
                c = PersonalAccounts.get(i);
            if (PersonalAccounts.get(i).getBalance() > 0)
                throw new BalanceRemainingException(PersonalAccounts.get(i).getBalance());
            else
                PersonalAccounts.remove(i);
        }
        if (c == null)
            throw new AccountNotFoundException(acctNum);
    }
    @Override
    public String toString(){
        return Name + " " + Surname.toUpperCase();
    }
}
class Company{
    private int id;
    private String Name;
    private ArrayList<BusinessAccount> BusinessAccounts = new ArrayList<>();

    public ArrayList<BusinessAccount> getBusinessAccounts() {
        return BusinessAccounts;
    }

    public Company(int id, String Name){
        if (id < 0)
            throw new InvalidIdException(id);
        else
            this.id = id;
        this.Name = Name;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }
    public void openAccount(String acctNum, double rate){
        BusinessAccount s = new BusinessAccount(acctNum,rate);
        this.BusinessAccounts.add(s);
    }
    public BusinessAccount getAccount(String acctNum){
        BusinessAccount c = null;
        for(int i = 0; i < BusinessAccounts.size();i++){
            if(BusinessAccounts.get(i).getAcctNumber().equals(acctNum))
                c = BusinessAccounts.get(i);
        }
        if(c == null)
            throw new AccountNotFoundException(acctNum);
        else return c;
    }
    public void closeAccount(String acctNum){
        BusinessAccount c = null;
        for(int i = 0; i < BusinessAccounts.size();i++){
            if(BusinessAccounts.get(i).getAcctNumber().equals(acctNum))
                c = BusinessAccounts.get(i);
            if (BusinessAccounts.get(i).getBalance() > 0)
                throw new BalanceRemainingException(BusinessAccounts.get(i).getBalance());
            else
                BusinessAccounts.remove(i);
        }
        if(c == null)
            throw new AccountNotFoundException(acctNum);
    }
    @Override
    public String toString(){
        return Name;
    }
}
class AccountNotFoundException extends RuntimeException{
    private String acctNum;
    public AccountNotFoundException(String acctNum){
        this.acctNum = acctNum;
    }
    @Override
    public String toString(){
        return "AccountNotFoundException: " + acctNum;
    }
}
class BalanceRemainingException extends RuntimeException{
    private double balance;
    public BalanceRemainingException(double balance){
        this.balance = balance;
    }
    @Override
    public String toString(){
        return "BalanceRemainingException: " + balance;
    }
    public double getBalance() {
        return balance;
    }
}
class CompanyNotFoundException extends RuntimeException{
    private int id;
    private String name;
    public CompanyNotFoundException(int id){
        this.id = id;
        this.name = null;
    }
    public CompanyNotFoundException(String name){
        Random random = new Random();
        this.name = name;
        this.id = random.nextInt(Integer.MAX_VALUE);
    }
    public CompanyNotFoundException(int id,String name){
        this.id = id;
        this.name = name;
    }
    @Override
    public String toString(){
        if(this.name != null)
            return "CompanyNotFoundException: name - " + name;
        else
            return "CompanyNotFoundException: id - " + id;
    }
}
class CustomerNotFoundException extends RuntimeException{
    private int id;
    private String name;
    private String surname;
    public CustomerNotFoundException(int id){
        this.id = id;
        this.name = null;
        this.surname = null;
    }
    public CustomerNotFoundException(String name,String surname){
        Random random = new Random();
        this.name = name;
        this.surname = surname;
        this.id = random.nextInt(Integer.MAX_VALUE);
    }
    public CustomerNotFoundException(int id,String name,String surname){
        this.id = id;
        this.name = name;
        this.surname = surname;
    }
    @Override
    public String toString(){
        if(this.name == null && this.surname == null)
            return "CustomerNotFoundException: id - " + id;
        else
            return "CustomerNotFoundException: name - " + name + " " + surname;
    }
}
class InvalidAmountException extends RuntimeException{
    private double amount;
    public InvalidAmountException(double amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "InvalidAmountException: " + amount;
    }
}
class InvalidIdException extends RuntimeException{
    private int id;
    public InvalidIdException(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "InvalidIdException: " + id;
    }
}
class transactionComparator implements Comparator<Transaction> {
    @Override
    public int compare(Transaction a,Transaction b){
        if(a.getType() > b.getType()) {
            return 1;
        }
        else if(a.getType() < b.getType()) {
            return -1;
        }
        else {
            if (a.getType() == 1 && b.getType() == 1) {
                if (a.getTo().compareTo(b.getTo()) > 0) {
                    return 1;
                } else if (a.getTo().compareTo(b.getTo()) < 0) {
                    return -1;
                } else
                    return 0;
            }
            else if(a.getType() == 2 && b.getType() == 2) {
                if (a.getTo().compareTo(b.getTo()) > 0) {
                    return 1;
                } else if (a.getTo().compareTo(b.getTo()) < 0) {
                    return -1;
                } else
                    return 0;
            }
            else {
                if (a.getFrom().compareTo(b.getFrom()) > 0) {
                    return 1;
                } else if (a.getFrom().compareTo(b.getFrom()) < 0) {
                    return -1;
                } else
                    return 0;
            }
        }
    }
}
